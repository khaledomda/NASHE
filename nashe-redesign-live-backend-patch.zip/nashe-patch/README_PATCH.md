# Nashe — redesign + live backend patch

Apply these files on top of your `khaledomda/NASHE` clone, on a new branch
(e.g. `feature/redesign-modern-ui-live-backend`).

## 1. Copy the files
Every file here mirrors its exact path in the repo. In GitHub Desktop /
your editor, copy each file into the same relative path, overwriting the
existing one (for genuinely new files there's nothing to overwrite).

New files:
- lib/db/src/schema/likes.ts
- artifacts/api-server/src/lib/storage.ts
- artifacts/mobile/lib/api.ts
- artifacts/mobile/app/video/[id].tsx
- artifacts/mobile/.env.example

Edited files (replace entirely):
- lib/db/src/schema/videos.ts
- lib/db/src/schema/index.ts
- lib/api-client-react/src/index.ts
- artifacts/api-server/package.json
- artifacts/api-server/src/middlewares/auth.ts
- artifacts/api-server/src/routes/videos.ts
- .env.example (repo root)
- artifacts/mobile/package.json
- artifacts/mobile/constants/colors.ts
- artifacts/mobile/constants/i18n.ts
- artifacts/mobile/context/AuthContext.tsx
- artifacts/mobile/app/_layout.tsx
- artifacts/mobile/app/login.tsx
- artifacts/mobile/app/(tabs)/index.tsx
- artifacts/mobile/app/(tabs)/upload.tsx

## 2. Install new dependencies
```
pnpm install
```
This pulls in `@aws-sdk/client-s3` and `@aws-sdk/s3-request-presigner`
(api-server) and `expo-video` (mobile).

## 3. Database migration
The schema gained a `likes` column on `videos` and a new `video_likes`
table. From `lib/db`:
```
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```
(or your existing migration command — check `lib/db/package.json` scripts)

## 4. Configure object storage
Fill in the new S3 section of `.env` (copied from `.env.example`) with your
Cloudflare R2 or AWS S3 credentials:
```
S3_BUCKET=
S3_REGION=
S3_ACCESS_KEY_ID=
S3_SECRET_ACCESS_KEY=
S3_ENDPOINT=            # R2 only
S3_PUBLIC_BASE_URL=     # public URL videos are served from
```
If the bucket isn't public, you'll want to front it with a CDN/public
bucket policy, or swap the GET side to presigned read URLs too — happy to
add that once you've got the bucket set up.

## 5. Point the mobile app at your API
Copy `artifacts/mobile/.env.example` to `artifacts/mobile/.env` and set
`EXPO_PUBLIC_API_URL` to your deployed api-server's URL (including the
`/api` prefix).

## What's now real vs. still to do

**Now real:**
- Registration and login call the actual `/auth/register` and
  `/auth/login` endpoints and store a JWT (`AuthContext`).
- Uploading a clip gets a presigned URL, uploads the real video file to
  your S3/R2 bucket, then registers it via `POST /videos`.
- The home feed fetches real videos from `GET /videos`.
- Video detail screen plays the real file, records a view
  (`POST /videos/:id/view`), and has a like bar — heart + count only, no
  dislike or comments — backed by `POST`/`DELETE /videos/:id/like`.

**Still mocked / follow-up work:**
- The admin approve/reject screen (`app/(tabs)/admin.tsx`) still shows
  static sample data — wiring it to `GET/POST /admin/videos` (or
  whatever you'd like that route to be) is a natural next step.
- The "scanning" moderation indicator in the upload screen is still a
  simulated client-side check; a real automated check (OCR/phone-number
  detection) needs a worker process, which is out of scope for a
  client-side patch.
- No cross-screen visual redesign pass yet beyond colors + the touched
  screens (login, home, upload, new video detail). Settings and admin
  still use the old look — say the word and I'll pass over those too.
